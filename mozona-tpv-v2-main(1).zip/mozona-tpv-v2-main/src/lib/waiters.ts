// =====================================================================
// MOZONA TPV — waiters v4.2.1 (persistencia JWT)
// =====================================================================
// Camareros: resolveRealTenantId, saveWaiter, listWaiters, deleteWaiter.
// Todo con JWT explicito via dbWrite o supabaseFetch.
// =====================================================================

import { supabase } from "./supabase";
import { supabaseFetch } from "./supabase-fetch";
import { getUserJwt } from "./auth-helpers";

const ZERO_UUID = "00000000-0000-0000-0000-000000000000";

export async function resolveRealTenantId(preferredId: string | null): Promise<string | null> {
    // 0) Si ya viene bueno
    if (preferredId && preferredId !== ZERO_UUID && preferredId !== "vip-bypass") {
        return preferredId;
    }

    // 1) LS
    if (typeof localStorage !== "undefined") {
        try {
            const raw = localStorage.getItem("mozona.current_tenant_id");
            if (raw && raw !== ZERO_UUID) return raw;
        } catch {}
    }

    // 2) AuthContext
    if (typeof localStorage !== "undefined") {
        try {
            const raw = localStorage.getItem("pos_current_user");
            if (raw) {
                const p = JSON.parse(raw);
                const tid = p?.tenant?.id || p?.user?.tenant_id;
                if (tid && tid !== ZERO_UUID) return tid;
            }
        } catch {}
    }

    // 3) BD via RPC get_first_active_tenant (con JWT si hay)
    if (supabase) {
        try {
            const jwt = getUserJwt();
            const r = await supabaseFetch("/rest/v1/rpc/get_first_active_tenant", {
                method: "POST",
                jwt,
                headers: { "Content-Type": "application/json" },
                body: "{}",
            });
            if (r.ok) {
                const tid = await r.json();
                if (typeof tid === "string" && tid !== ZERO_UUID) return tid;
            }
        } catch {}
        try {
            const { data, error } = await supabase.rpc("get_first_active_tenant");
            if (!error && typeof data === "string" && data !== ZERO_UUID) {
                return data;
            }
        } catch {}
    }

    return null;
}

export interface WaiterRow {
    id?: string;
    tenant_id?: string;
    username?: string;
    full_name?: string;
    pin?: string;
    role?: string;
    created_at?: string;
}

export async function listWaiters(tenantId: string | null): Promise<WaiterRow[]> {
    const realId = await resolveRealTenantId(tenantId);
    if (!realId) return [];

    const jwt = getUserJwt();
    try {
        const r = await supabaseFetch(
            `/rest/v1/waiters?tenant_id=eq.${realId}&order=username.asc`,
            { jwt }
        );
        if (!r.ok) {
            console.warn("[waiters] list HTTP", r.status);
            return [];
        }
        return await r.json();
    } catch (e: any) {
        console.warn("[waiters] list exception:", e?.message);
        return [];
    }
}

export async function saveWaiter(input: {
    tenantId: string | null;
    username: string;
    full_name?: string;
    pin?: string;
    role?: string;
    id?: string;
}): Promise<{ ok: boolean; data?: any; error?: string; status?: number }> {
    const realId = await resolveRealTenantId(input.tenantId);
    if (!realId) {
        return { ok: false, error: "Sin tenantId válido" };
    }
    if (!input.username || input.username.length < 2) {
        return { ok: false, error: "username demasiado corto" };
    }

    const jwt = getUserJwt();
    const row = {
        tenant_id: realId,
        username: input.username.trim().slice(0, 50),
        full_name: (input.full_name ?? input.username).trim().slice(0, 120),
        pin: input.pin ?? null,
        role: input.role ?? "waiter",
    };

    try {
        if (input.id) {
            const r = await supabaseFetch(
                `/rest/v1/waiters?id=eq.${encodeURIComponent(input.id)}&tenant_id=eq.${realId}`,
                {
                    method: "PATCH",
                    jwt,
                    body: JSON.stringify({
                        username: row.username,
                        full_name: row.full_name,
                        pin: row.pin,
                        role: row.role,
                    }),
                }
            );
            if (!r.ok) {
                const errText = await r.text().catch(() => "");
                return { ok: false, error: errText, status: r.status };
            }
            console.log("[waiters] ✅ UPDATE", input.username);
            return { ok: true, status: r.status };
        } else {
            const r = await supabaseFetch("/rest/v1/waiters", {
                method: "POST",
                jwt,
                headers: { "Prefer": "return=representation" },
                body: JSON.stringify(row),
            });
            if (!r.ok) {
                const errText = await r.text().catch(() => "");
                return { ok: false, error: errText, status: r.status };
            }
            const data = await r.json();
            console.log("[waiters] ✅ INSERT", input.username);
            return { ok: true, data, status: r.status };
        }
    } catch (e: any) {
        console.error("[waiters] save exception:", e?.message);
        return { ok: false, error: e?.message };
    }
}

export async function deleteWaiter(tenantId: string | null, id: string): Promise<{ ok: boolean; error?: string; status?: number }> {
    const realId = await resolveRealTenantId(tenantId);
    if (!realId) return { ok: false, error: "Sin tenantId" };

    const jwt = getUserJwt();
    try {
        const r = await supabaseFetch(
            `/rest/v1/waiters?id=eq.${encodeURIComponent(id)}&tenant_id=eq.${realId}`,
            { method: "DELETE", jwt }
        );
        if (!r.ok) {
            const errText = await r.text().catch(() => "");
            return { ok: false, error: errText, status: r.status };
        }
        console.log("[waiters] ✅ DELETE", id);
        return { ok: true };
    } catch (e: any) {
        return { ok: false, error: e?.message };
    }
}

// ★ Compatibilidad: keep findByPinCached for useWaiterAuth.ts
let _waitersCache: { ts: number; rows: WaiterRow[] } | null = null;
export async function syncWaiters(tenantId: string | null, force = false): Promise<WaiterRow[]> {
    const realId = await resolveRealTenantId(tenantId);
    if (!realId) return [];
    if (_waitersCache && !force && Date.now() - _waitersCache.ts < 60_000) {
        return _waitersCache.rows;
    }
    const rows = await listWaiters(realId);
    _waitersCache = { ts: Date.now(), rows };
    return rows;
}

export async function findByPinCached(tenantId: string | null, pin: string): Promise<WaiterRow | null> {
    if (!pin || pin.length < 1) return null;
    const rows = await syncWaiters(tenantId);
    return rows.find(w => w.pin === pin) ?? null;
}

// ★ Compatibilidad: useWaiters.ts pide listCachedWaiters
export async function listCachedWaiters(tenantId: string | null, ttlMs = 60_000): Promise<WaiterRow[]> {
    if (_waitersCache && Date.now() - _waitersCache.ts < ttlMs) {
        return _waitersCache.rows;
    }
    return await syncWaiters(tenantId, true);
}

// ★ Compatibilidad: useWaiters.ts pide createWaiter/updateWaiter/deleteWaiterById
export async function createWaiter(input: { tenant_id: string; username: string; full_name?: string; pin?: string; role?: string }): Promise<{ ok: boolean; data?: any; error?: string }> {
    return await saveWaiter(input);
}

export async function updateWaiter(id: string, patch: { username?: string; full_name?: string; pin?: string; role?: string; tenant_id: string }): Promise<{ ok: boolean; error?: string }> {
    const jwt = getUserJwt();
    const realId = await resolveRealTenantId(patch.tenant_id ?? null);
    if (!realId) return { ok: false, error: "Sin tenantId" };
    try {
        const r = await supabaseFetch(
            `/rest/v1/waiters?id=eq.${encodeURIComponent(id)}&tenant_id=eq.${realId}`,
            {
                method: "PATCH",
                jwt,
                body: JSON.stringify({
                    username: patch.username,
                    full_name: patch.full_name,
                    pin: patch.pin,
                    role: patch.role,
                }),
            }
        );
        if (!r.ok) {
            const t = await r.text().catch(() => "");
            return { ok: false, error: t };
        }
        // invalidar cache
        _waitersCache = null;
        return { ok: true };
    } catch (e: any) {
        return { ok: false, error: e?.message };
    }
}

export async function deleteWaiterById(id: string): Promise<{ ok: boolean; error?: string }> {
    const realId = await resolveRealTenantId(null);
    if (!realId) return { ok: false, error: "Sin tenantId" };
    const result = await deleteWaiter(realId, id);
    _waitersCache = null;
    return result;
}

export async function resetWaiterPassword(id: string, newPin: string): Promise<{ ok: boolean; error?: string }> {
    const realId = await resolveRealTenantId(null);
    if (!realId) return { ok: false, error: "Sin tenantId" };
    const r = await updateWaiter(id, { tenant_id: realId, pin: newPin });
    return r;
}
